# SmartBioGen

SmartBioGen is a lightweight AI-style Bio Generator built for instant use.

## Features
- Name, Profession, and Tone input
- Generates short bios
- Copy to clipboard feature
- Mobile friendly
- Powered by Smart AI Partners

## How to Deploy
1. Upload to GitHub
2. Connect with Vercel for instant deployment
